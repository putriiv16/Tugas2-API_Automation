const dotenv = require("dotenv");
dotenv.config();

console.log("USERNAME from process.env:", process.env.API_USERNAME);
console.log("All env variables:", process.env);